#ifndef TEST_LINKEDLIST_H
#define TEST_LINKEDLIST_H

int testQueueConstructor();
int testQueueEnqueue();
int testQueueDequeue();
int testQueueClear();

int printResult(int cond);
void header(char* msg);
#endif
