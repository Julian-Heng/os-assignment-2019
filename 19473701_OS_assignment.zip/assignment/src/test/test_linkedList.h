#ifndef TEST_LINKEDLIST_H
#define TEST_LINKEDLIST_H

int testListConstructor();
int testListInsert();
int testListRemove();
int testListPeek();
int testListClear();

int printResult(int cond);
void header(char* msg);
#endif
